package com.web.adv.pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.adv.common.Common;
import com.adv.helper.IConstants;
import com.relevantcodes.extentreports.LogStatus;

public class ADVLoginPage {

	@FindBy(xpath = ".//div[@class='logo']//span[@class='roboto-medium ng-binding']")
	private WebElement logo;

	@FindBy(xpath = ".//a[@id='hrefUserIcon']")
	private WebElement userLoginIcon;

	@FindBy(xpath = ".//a[@class='create-new-account ng-scope']")
	private WebElement createNewAccountLink;

	@FindBy(xpath = ".//h3[@translate='CREATE_ACCOUNT']")
	private WebElement CREATEACCOUNTPageHeader;
	
	@FindBy(xpath = ".//input[@name='usernameRegisterPage']")
	private WebElement usernameRegisterPage;
	
	@FindBy(xpath = ".//input[@name='usernameRegisterPage']/following-sibling::label[contains(text(),'Username field is required')]")
	private WebElement usernameRegisterPageVerification;
	
	@FindBy(xpath = ".//input[@name='emailRegisterPage']")
	private WebElement emailRegisterPage;
	
	@FindBy(xpath = ".//input[@name='passwordRegisterPage']")
	private WebElement passwordRegisterPage;
	
	@FindBy(xpath = ".//input[@name='confirm_passwordRegisterPage']")
	private WebElement confirmpasswordRegisterPage;
	
	@FindBy(xpath = ".//input[@name='first_nameRegisterPage']")
	private WebElement firstnameRegisterPage;
	
	@FindBy(xpath = ".//input[@name='last_nameRegisterPage']")
	private WebElement lastnameRegisterPage;
	
	@FindBy(xpath = ".//input[@name='phone_numberRegisterPage']")
	private WebElement phonenumberRegisterPage;
	
	@FindBy(xpath = ".//input[@name='i_agree']")
	private WebElement iAgreeCheckBox;
	
	@FindBy(xpath = ".//button[@id='register_btnundefined']")
	private WebElement registerBtnundefined;
	
	
	
	private WebDriver driver;
	private Common common;

	public ADVLoginPage(WebDriver driver2) {
		driver = driver2;
		common = new Common(driver2);
		PageFactory.initElements(driver2, this);
	}
	/**
	 * Method To check login page
	 * @author 
	 * @throws InterruptedException
	 * @throws IOException
	 */

	public boolean isLogoDisplayed(String logoText, String ScreenshotRequire){
		boolean flag=false;
		try{
			common.waitForElementToBeDisplayed(logo, 60);
			Common.isElementDisplayed(driver, logo, IConstants.LOW_WAIT_TIME);
			if(logo.getText().contains(logoText)){
				System.out.println("Logo Displayed");
				WebTestCase.getTest().log(LogStatus.PASS, "Logo Displayed" + common.captureScreenshot(ScreenshotRequire));
				flag=true;
			}else {
				System.out.println("Logo not Displayed");
				WebTestCase.getTest().log(LogStatus.FAIL, "Logo not Displayed" + common.captureScreenshot(ScreenshotRequire));
				flag=false;
			
			}
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return flag;
	}

	
	/**
	 * This method is clickuserLoginIcon.
	 * @Author 
	 * @throws AWTException
	 * @throws InterruptedException
	 */
	public String clickuserLoginIcon(String ScreenshotRequire) throws InterruptedException{
		String img=null;
		try{
			Common.isElementDisplayed(driver, userLoginIcon, IConstants.LOW_WAIT_TIME);
			common.waitForElementToBeDisplayed(userLoginIcon, 60);
			common.clickOnObject(userLoginIcon, "userLoginIcon");
			System.out.println("cliked on user Login Icon");
			
			Common.isElementDisplayed(driver, createNewAccountLink, IConstants.LOW_WAIT_TIME);
			common.waitForElementToBeDisplayed(createNewAccountLink, 60);
			common.clickOnObject(createNewAccountLink, "createNewAccountLink");
			System.out.println("create New Account Link");
			
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;

	}
	
	/**
	 * This method is verifyCreateAccountPage.
	 * @Author 
	 * @throws AWTException
	 * @throws InterruptedException
	 */
	public String verifyCreateAccountPage(String ScreenshotRequire) throws InterruptedException{
		String img=null;
		try{
			common.waitForElementLoaded(CREATEACCOUNTPageHeader,60);
			Common.isElementDisplayed(driver, CREATEACCOUNTPageHeader, IConstants.LOW_WAIT_TIME);
			System.out.println("CREATE ACCOUNT Page Header displaying");
			WebTestCase.getTest().log(LogStatus.PASS,"CREATE ACCOUNT Page Header displaying" + common.captureScreenshot("true"));
			
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;

	}
	
	/**
	 * This method is userRegistrationVerification.
	 * @Author 
	 * @throws AWTException
	 * @throws InterruptedException
	 */
	public String userRegistrationVerification(String  username, String email,String pass,  String firstName, String lastName, String phoneno,String ScreenshotRequire) throws InterruptedException{
		String img=null;
		try{
			// here I am verifying mandatory for username only, the similar type of script will be applicable for other field verification
			
			// genaret randon userid
			int rand= Common.generateRandomIntIntRange(1, 100);
			username= username + rand;
			
			common.waitForElementToBeDisplayed(usernameRegisterPage, 60);
			Common.isElementDisplayed(driver, usernameRegisterPage, IConstants.LOW_WAIT_TIME);
			common.clickOnObject(usernameRegisterPage, "usernameRegisterPage");
			usernameRegisterPage.sendKeys(Keys.TAB);
			Common.isElementDisplayed(driver, usernameRegisterPageVerification, 60);
			WebTestCase.getTest().log(LogStatus.PASS,"username Register Page Verification alert showing:: " +usernameRegisterPageVerification.getText()+ common.captureScreenshot("true"));
			common.setObjectValue(usernameRegisterPage, "usernameRegisterPage", username);
			WebTestCase.getTest().log(LogStatus.PASS,"Entered value on username Register field as::"  + username+ common.captureScreenshot("true"));
			
			
			common.waitForElementToBeDisplayed(emailRegisterPage, 60);
			Common.isElementDisplayed(driver, emailRegisterPage, IConstants.LOW_WAIT_TIME);
			common.setObjectValue(emailRegisterPage, "emailRegisterPage", email);
			WebTestCase.getTest().log(LogStatus.PASS,"Entered value on username field as::"  + email);
			
			
			common.waitForElementToBeDisplayed(passwordRegisterPage, 60);
			Common.isElementDisplayed(driver, passwordRegisterPage, IConstants.LOW_WAIT_TIME);
			common.setObjectValue(passwordRegisterPage, "passwordRegisterPage", "Google12345");
			WebTestCase.getTest().log(LogStatus.PASS,"Entered value on password field as::"  + pass);
			
			
			common.waitForElementToBeDisplayed(confirmpasswordRegisterPage, 60);
			Common.isElementDisplayed(driver, confirmpasswordRegisterPage, IConstants.LOW_WAIT_TIME);
			common.setObjectValue(confirmpasswordRegisterPage, "confirmpasswordRegisterPage", "Google12345");
			WebTestCase.getTest().log(LogStatus.PASS,"Entered value on confirm password field as::"  + pass);
			
			common.waitForElementToBeDisplayed(firstnameRegisterPage, 60);
			Common.isElementDisplayed(driver, firstnameRegisterPage, IConstants.LOW_WAIT_TIME);
			common.setObjectValue(firstnameRegisterPage, "firstnameRegisterPage", firstName);
			WebTestCase.getTest().log(LogStatus.PASS,"Entered value on firstName field as::"  + firstName);
			
			common.waitForElementToBeDisplayed(lastnameRegisterPage, 60);
			Common.isElementDisplayed(driver, lastnameRegisterPage, IConstants.LOW_WAIT_TIME);
			common.setObjectValue(lastnameRegisterPage, "lastnameRegisterPage", lastName);
			WebTestCase.getTest().log(LogStatus.PASS,"Entered value on lastName field as::"  + lastName);
			
			common.waitForElementToBeDisplayed(phonenumberRegisterPage, 60);
			Common.isElementDisplayed(driver, phonenumberRegisterPage, IConstants.LOW_WAIT_TIME);
			common.setObjectValue(phonenumberRegisterPage, "phonenumberRegisterPage", phoneno);
			WebTestCase.getTest().log(LogStatus.PASS,"Entered value on phoneNumber field as::" + phoneno);
			
			common.waitForElementToBeDisplayed(iAgreeCheckBox, 60);
			Common.isElementDisplayed(driver, iAgreeCheckBox, IConstants.LOW_WAIT_TIME);
			common.clickOnObject(iAgreeCheckBox, "iAgreeCheckBox");
			WebTestCase.getTest().log(LogStatus.PASS,"selected I Agree CheckBox");
			
			common.waitForElementToBeDisplayed(registerBtnundefined, 60);
			Common.isElementDisplayed(driver, registerBtnundefined, IConstants.LOW_WAIT_TIME);
			common.clickOnObject(registerBtnundefined, "Register Button");
			WebTestCase.getTest().log(LogStatus.PASS,"clicked on registerBtnundefined" + common.captureScreenshot("true"));
			
			Thread.sleep(10000);
		}
		catch(java.lang.AssertionError exp1){
			System.out.println("Got Assertion Error.."+exp1);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp1.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp1.getMessage());
		}
		catch(Exception exp2){
			System.out.println("Got Exception.."+exp2);
			WebTestCase.getTest().log(LogStatus.FAIL,
					exp2.getMessage() + common.captureScreenshot("true"));
			Assert.fail(exp2.getMessage());
		}
		return img;

	}
	
}
